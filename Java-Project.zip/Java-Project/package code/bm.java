package bm;
public abstract class bm
{
	public static String name = "BIG MART";
}