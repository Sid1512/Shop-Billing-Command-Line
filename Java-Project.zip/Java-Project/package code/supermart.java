package supermart;
public interface supermart
{
	String name = "BIG MART";
	public String get_item(int x);
	public int get_price(int x);
}